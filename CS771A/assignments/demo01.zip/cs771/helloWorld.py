'''
    Package: cs771
    Module: helloWorld
    Author: Puru
    Institution: CSE, IIT Kanpur
    License: GNU GPL v3.0
    
    Just a little something nice to get ourselves started
'''

# Our course name
courseName = "CS771: Introduction to Machine Learning"

# Welcome message for the course
def helloWorld( name ):
    print( "Hello " + name + ", welcome to " + courseName )