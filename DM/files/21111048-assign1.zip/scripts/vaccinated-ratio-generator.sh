python code_data/q8.py
