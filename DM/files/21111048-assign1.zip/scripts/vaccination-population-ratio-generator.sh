python code_data/q6.py
