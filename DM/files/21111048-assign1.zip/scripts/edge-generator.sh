python code_data/q1-q2.py
