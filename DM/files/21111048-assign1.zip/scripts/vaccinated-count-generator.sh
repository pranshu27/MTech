python code_data/q5.py
