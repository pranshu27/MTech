python code_data/q7.py
