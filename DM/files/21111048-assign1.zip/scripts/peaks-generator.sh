python code_data/q4.py
