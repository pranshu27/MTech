python code_data/q9.py
