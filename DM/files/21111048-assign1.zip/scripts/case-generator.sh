python code_data/q3.py
